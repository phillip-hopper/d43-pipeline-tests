### Get Involved!

We want to make this visual mini-Bible available in_every language of the world_ and you can help! This is not impossible—we think it can happen if the whole body of Christ works together to translate & distribute this resource.
### Share Freely

Give as many copies of this book away as you want, without restriction. All digital versions are free online, and because of the open license we are using, you can even republish Open Bible Stories commercially anywhere in the world without paying royalties! Find out more at [http://openbiblestories.com](http://openbiblestories.com).

### Extend!

Get Open Bible Stories as videos and mobile phone applications in other languages at [http://openbiblestories.com](http://openbiblestories.com). On the website, you can also get help translating Open Bible Stories into_your_ language.
