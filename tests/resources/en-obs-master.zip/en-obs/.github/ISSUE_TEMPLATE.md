**Thank you so much for submitting a suggested change.**

We ask that you title the issue with the Story Title or number and chunk or frame information. For example you will type in the Title field above:

    Story 16, Chunk 4

OR

    16-04

Will you please start your suggestion with a copy of the current text and then put 2 blank lines and then your suggested change below that. Then provide a reason for the suggestion.

For example: 

    The Israelites were so scared; they hid in caves so the Midianites would not find them." (this is the text of the OBS story)

    The Israelites were so scared**,** they hid in caves so the Midianites would not find them." (this is a suggested change - with the suggestion in bold)

Reason for the suggestion: replace the semi-colon with a comma.

**We really appreciate your help in making the resources the best they can be!**


(You can replace all of the above text with your suggestions.)